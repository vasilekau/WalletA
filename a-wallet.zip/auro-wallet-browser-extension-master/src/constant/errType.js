export const ERROR_TYPE = {
    "CanceRequest":"Cancel Request"
}