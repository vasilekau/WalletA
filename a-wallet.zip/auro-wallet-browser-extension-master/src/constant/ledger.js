/**
 * ledger connect status
 */
export const LEDGER_STATUS = {
  READY: "READY",
  LEDGER_DISCONNECT: "LEDGER_DISCONNECT",
  LEDGER_CONNECT_APP_NOT_OPEN: "LEDGER_CONNECT_APP_NOT_OPEN",
};


/** ledger page type */
export const LEDGER_PAGE_TYPE = {
  permissionGrant:"permissionGrant"
}