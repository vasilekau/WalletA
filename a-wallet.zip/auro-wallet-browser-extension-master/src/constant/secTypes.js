
/**
 * delete account key
 */
export const SEC_DELETE_ACCOUNT = "SEC_DELETE_ACCOUNT";


/**
 * show private key
 */
export const SEC_SHOW_PRIVATE_KEY = "SEC_SHOW_PRIVATE_KEY";


/**
 * show mnemonic
 */
export const SEC_SHOW_MNEMONIC = "SEC_SHOW_MNEMONIC";