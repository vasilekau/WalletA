import MinaProvider from '@aurowallet/mina-provider';
window.mina = new MinaProvider()